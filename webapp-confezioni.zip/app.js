(function(){
  const { useState, useMemo } = React;

  const currency = (n) => new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(n);

  async function fetchProducts() {
    const res = await fetch("data/prodotti.json?_=" + Date.now());
    if (!res.ok) throw new Error("Impossibile caricare data/prodotti.json");
    return res.json();
  }

  function App() {
    const [all, setAll] = useState([]);
    const [q, setQ] = useState("");
    const [settore, setSettore] = useState("Tutti");
    const [tipologia, setTipologia] = useState("Tutte");
    const [linea, setLinea] = useState("Tutte");
    const [materiale, setMateriale] = useState("Tutti");
    const [soloPersonalizzabili, setSoloPersonalizzabili] = useState(false);
    const [viewPrezzo, setViewPrezzo] = useState("anonimo"); // anonimo | personalizzato
    const [cart, setCart] = useState([]);

    React.useEffect(()=>{
      fetchProducts().then(setAll).catch(err => alert(err.message));
    },[]);

    const settori = useMemo(()=>["Tutti", ...Array.from(new Set(all.map(p=>p.settore)))], [all]);
    const tipologie = useMemo(()=>["Tutte", ...Array.from(new Set(all.filter(p=>settore==="Tutti"||p.settore===settore).map(p=>p.tipologia)))], [all, settore]);
    const linee = useMemo(()=>["Tutte", ...Array.from(new Set(all.filter(p=>settore==="Tutti"||p.settore===settore).filter(p=>tipologia==="Tutte"||p.tipologia===tipologia).map(p=>p.linea)))], [all, settore, tipologia]);
    const materiali = useMemo(()=>["Tutti", ...Array.from(new Set(all.map(p=>p.materiale)))], [all]);

    const filtered = useMemo(()=>{
      return all
        .filter(p => settore==="Tutti" ? true : p.settore===settore)
        .filter(p => tipologia==="Tutte" ? true : p.tipologia===tipologia)
        .filter(p => linea==="Tutte" ? true : p.linea===linea)
        .filter(p => materiale==="Tutti" ? true : p.materiale===materiale)
        .filter(p => soloPersonalizzabili ? p.personalizzabile : true)
        .filter(p => q.trim()==="" ? true : (`${p.codice} ${p.articolo} ${p.tipologia} ${p.linea} ${p.colore}`.toLowerCase().includes(q.trim().toLowerCase())));
    }, [all, settore, tipologia, linea, materiale, soloPersonalizzabili, q]);

    const addToCart = (p) => {
      const prezzo = viewPrezzo==="anonimo" ? p.prezzoAnonimo : p.prezzoPersonalizzato;
      setCart(prev => {
        const idx = prev.findIndex(i => i.codice===p.codice && i.personalizzato === (viewPrezzo==="personalizzato"));
        if (idx>=0) {
          const copy = prev.slice(); copy[idx].qta += 1; return copy;
        }
        return [...prev, { codice: p.codice, titolo: `${p.articolo} – ${p.linea}`, qta: 1, prezzo, personalizzato: viewPrezzo==="personalizzato" }];
      });
    };

    const cartTotal = cart.reduce((s,i)=>s+i.qta*i.prezzo,0);

    const exportCSV = () => {
      if (cart.length===0) return;
      const rows = [["codice","articolo","qta","prezzo_unit","importo","personalizzazione"]]
        .concat(cart.map(i => [i.codice, i.titolo, i.qta, i.prezzo, i.qta*i.prezzo, i.personalizzato?"Personalizzato":"Anonimo"]));
      const csv = rows.map(r => r.map(x => (typeof x==="string" && x.includes(",") ? `"${x}"` : x)).join(",")).join("\n");
      const blob = new Blob([csv], {type:"text/csv;charset=utf-8;"});
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `preventivo_confezioni_${new Date().toISOString().slice(0,10)}.csv`;
      a.click();
    };

    const printPage = () => window.print();

    const mailto = () => {
      const body = encodeURIComponent(
        cart.map(i=>`• ${i.codice} – ${i.titolo} x${i.qta} @ ${currency(i.prezzo)} = ${currency(i.qta*i.prezzo)}`).join("\n")
        + `\n\nTotale: ${currency(cartTotal)}\n\nRichiesta da web app confezioni.`
      );
      window.location.href = `mailto:info@tecnobox.net?subject=Richiesta%20preventivo%20confezioni&body=${body}`;
    };

    return React.createElement(React.Fragment, null,
      React.createElement("section", {className:"grid grid-cols-1 lg:grid-cols-6 gap-3 items-end"},
        React.createElement("div", {className:"lg:col-span-2"},
          React.createElement("label", {className:"text-xs font-medium"}, "Ricerca"),
          React.createElement("input", {className:"mt-1 w-full border rounded-md px-3 h-10", placeholder:"Codice, tipologia, linea, colore…", value:q, onChange:e=>setQ(e.target.value)})
        ),
        React.createElement("div", null,
          React.createElement("label", {className:"text-xs font-medium"}, "Settore"),
          React.createElement("select", {className:"mt-1 w-full border rounded-md px-3 h-10", value:settore, onChange:e=>setSettore(e.target.value)},
            settori.map(s=>React.createElement("option", {key:s, value:s}, s))
          )
        ),
        React.createElement("div", null,
          React.createElement("label", {className:"text-xs font-medium"}, "Tipologia"),
          React.createElement("select", {className:"mt-1 w-full border rounded-md px-3 h-10", value:tipologia, onChange:e=>setTipologia(e.target.value)},
            tipologie.map(t=>React.createElement("option", {key:t, value:t}, t))
          )
        ),
        React.createElement("div", null,
          React.createElement("label", {className:"text-xs font-medium"}, "Linea / Colore"),
          React.createElement("select", {className:"mt-1 w-full border rounded-md px-3 h-10", value:linea, onChange:e=>setLinea(e.target.value)},
            linee.map(l=>React.createElement("option", {key:l, value:l}, l))
          )
        ),
        React.createElement("div", null,
          React.createElement("label", {className:"text-xs font-medium"}, "Materiale"),
          React.createElement("select", {className:"mt-1 w-full border rounded-md px-3 h-10", value:materiale, onChange:e=>setMateriale(e.target.value)},
            materiali.map(m=>React.createElement("option", {key:m, value:m}, m))
          )
        )
      ),

      React.createElement("div", {className:"mt-3 flex flex-wrap items-center gap-2"},
        React.createElement("button", {className:`px-3 h-9 rounded-md border ${soloPersonalizzabili?'bg-brand-500 text-white border-brand-500':'bg-white'}`, onClick:()=>setSoloPersonalizzabili(v=>!v)}, "Solo personalizzabili"),
        React.createElement("div", {className:"ml-auto flex items-center gap-2 text-sm"},
          React.createElement("span", {className:"px-2 py-1 bg-neutral-100 rounded"}, "Prezzo:"),
          React.createElement("button", {className:`px-3 h-9 rounded-md border ${viewPrezzo==='anonimo'?'bg-brand-500 text-white border-brand-500':'bg-white'}`, onClick:()=>setViewPrezzo('anonimo')}, "Anonimo"),
          React.createElement("button", {className:`px-3 h-9 rounded-md border ${viewPrezzo==='personalizzato'?'bg-brand-500 text-white border-brand-500':'bg-white'}`, onClick:()=>setViewPrezzo('personalizzato')}, "Personalizzato"),
          React.createElement("button", {className:"px-3 h-9 rounded-md border", onClick:()=>{
            const el = document.getElementById('sheet-cart'); el && el.showModal();
          }}, "Carrello (", cart.length, ")")
        )
      ),

      filtered.length===0 ? React.createElement("div", {className:"text-center text-sm text-neutral-500 py-16"},"Nessun risultato. Prova ad allentare i filtri.") : null,

      React.createElement("div", {className:"mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"},
        filtered.map(p => React.createElement("div", {key:p.codice, className:"bg-white border rounded-lg overflow-hidden shadow-sm hover:shadow-md transition"},
          React.createElement("div", {className:"aspect-[4/3] bg-white overflow-hidden"},
            React.createElement("img", {src:p.image, alt:p.articolo, className:"w-full h-full object-cover"})
          ),
          React.createElement("div", {className:"p-4"},
            React.createElement("div", {className:"flex items-start gap-2"},
              React.createElement("div", {className:"grow"},
                React.createElement("div", {className:"text-sm text-neutral-500"}, p.linea),
                React.createElement("h3", {className:"font-semibold leading-tight"}, p.articolo),
                React.createElement("div", {className:"text-xs text-neutral-500"}, "Cod. ", p.codice, " • ", p.tipologia)
              ),
              React.createElement("span", {className:"text-[11px] px-2 py-1 bg-neutral-100 rounded"}, p.settore)
            ),
            React.createElement("div", {className:"mt-2 grid grid-cols-2 gap-2 text-xs text-neutral-600"},
              React.createElement("div", null, React.createElement("span", {className:"font-medium"},"Materiale:"), " ", p.materiale),
              React.createElement("div", null, React.createElement("span", {className:"font-medium"},"Eco:"), " ", p.eco),
              React.createElement("div", null, React.createElement("span", {className:"font-medium"},"Confezione:"), " ", p.confezione),
              React.createElement("div", null, React.createElement("span", {className:"font-medium"},"Disponibilità:"), " ", p.disponibilita)
            ),
            React.createElement("div", {className:"mt-3 flex items-center justify-between"},
              React.createElement("div", {className:"text-lg font-semibold"},
                viewPrezzo==="anonimo" ? currency(p.prezzoAnonimo) : currency(p.prezzoPersonalizzato)
              ),
              React.createElement("div", {className:"flex items-center gap-2"},
                React.createElement("span", {className:`text-[11px] px-2 py-1 rounded ${p.personalizzabile?'bg-brand-500 text-white':'bg-neutral-100'}`}, p.personalizzabile ? "Personalizzabile" : "Anonimo"),
                React.createElement("button", {className:"px-3 h-9 rounded-md bg-brand-500 text-white", onClick:()=>addToCart(p)}, "Aggiungi")
              )
            ),
            p.note ? React.createElement("p", {className:"mt-2 text-xs text-neutral-500"}, p.note) : null
          )
        ))
      ),

      React.createElement("dialog", {id:"sheet-cart", className:"rounded-lg w-full max-w-lg p-0 border"},
        React.createElement("form", {method:"dialog"},
          React.createElement("div", {className:"p-4 border-b flex items-center justify-between"},
            React.createElement("h2", {className:"font-semibold"},"Carrello"),
            React.createElement("button", {className:"px-3 h-9 rounded-md border", onClick:(e)=>{e.preventDefault(); document.getElementById('sheet-cart').close();}}, "Chiudi")
          )
        ),
        React.createElement("div", {className:"p-4 space-y-3 max-h-[60vh] overflow-y-auto"},
          cart.length===0 ? React.createElement("p", {className:"text-sm text-neutral-500"},"Nessun articolo nel carrello.") : null,
          cart.map((i, idx) => React.createElement("div", {key:idx, className:"border rounded-md p-3"},
            React.createElement("div", {className:"font-medium"}, i.titolo),
            React.createElement("div", {className:"text-xs text-neutral-500"}, "Cod. ", i.codice),
            React.createElement("div", {className:"mt-1 flex items-center gap-2 text-sm"},
              React.createElement("span", null, currency(i.prezzo)),
              React.createElement("span", null, "×"),
              React.createElement("input", {
                value:i.qta, type:"number", className:"h-8 w-16 border rounded px-2",
                min:1, onChange:e=>{
                  const qta = Math.max(1, parseInt(e.target.value || "1", 10));
                  const copy = cart.slice(); copy[idx].qta = qta; setCart(copy);
                }
              }),
              React.createElement("span", {className:"ml-auto font-medium"}, currency(i.qta*i.prezzo)),
              React.createElement("button", {className:"px-3 h-8 rounded-md border", onClick:()=>{
                const copy = cart.slice(); copy.splice(idx,1); setCart(copy);
              }}, "Rimuovi")
            )
          ))
        ),
        React.createElement("div", {className:"p-4 border-t flex items-center justify-between"},
          React.createElement("div", {className:"font-semibold"},"Totale"),
          React.createElement("div", {className:"text-lg font-semibold"}, currency(cartTotal))
        ),
        React.createElement("div", {className:"p-4 grid grid-cols-2 gap-2"},
          React.createElement("button", {className:"px-3 h-10 rounded-md border", onClick:exportCSV}, "Esporta CSV"),
          React.createElement("button", {className:"px-3 h-10 rounded-md border", onClick:printPage}, "Stampa"),
          React.createElement("button", {className:"col-span-2 px-3 h-10 rounded-md bg-brand-500 text-white", onClick:mailto}, "Richiedi preventivo via email")
        )
      )
    );
  }

  const root = ReactDOM.createRoot(document.getElementById("root"));
  root.render(React.createElement(App));
})();